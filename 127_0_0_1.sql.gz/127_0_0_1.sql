-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 09 déc. 2025 à 17:36
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Structure de la table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) NOT NULL DEFAULT '',
  `user` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Structure de la table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) NOT NULL,
  `col_name` varchar(64) NOT NULL,
  `col_type` varchar(64) NOT NULL,
  `col_length` text DEFAULT NULL,
  `col_collation` varchar(64) NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) DEFAULT '',
  `col_default` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Structure de la table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `transformation` varchar(255) NOT NULL DEFAULT '',
  `transformation_options` varchar(255) NOT NULL DEFAULT '',
  `input_transformation` varchar(255) NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Structure de la table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) NOT NULL,
  `settings_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Structure de la table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL,
  `export_type` varchar(10) NOT NULL,
  `template_name` varchar(64) NOT NULL,
  `template_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

--
-- Déchargement des données de la table `pma__export_templates`
--

UPDATE `pma__export_templates` SET `id` = 1,`username` = 'root',`export_type` = 'server',`template_name` = 'promoapp',`template_data` = '{\"quick_or_custom\":\"custom\",\"what\":\"sql\",\"db_select[]\":[\"phpmyadmin\",\"promo_app\",\"test\"],\"aliases_new\":\"\",\"output_format\":\"sendit\",\"filename_template\":\"@SERVER@\",\"remember_template\":\"on\",\"charset\":\"utf-8\",\"compression\":\"gzip\",\"maxsize\":\"\",\"codegen_structure_or_data\":\"data\",\"codegen_format\":\"0\",\"csv_separator\":\",\",\"csv_enclosed\":\"\\\"\",\"csv_escaped\":\"\\\"\",\"csv_terminated\":\"AUTO\",\"csv_null\":\"NULL\",\"csv_columns\":\"something\",\"csv_structure_or_data\":\"data\",\"excel_null\":\"NULL\",\"excel_columns\":\"something\",\"excel_edition\":\"win\",\"excel_structure_or_data\":\"data\",\"json_structure_or_data\":\"data\",\"json_unicode\":\"something\",\"latex_caption\":\"something\",\"latex_structure_or_data\":\"structure_and_data\",\"latex_structure_caption\":\"Structure de la table @TABLE@\",\"latex_structure_continued_caption\":\"Structure de la table @TABLE@ (suite)\",\"latex_structure_label\":\"tab:@TABLE@-structure\",\"latex_relation\":\"something\",\"latex_comments\":\"something\",\"latex_mime\":\"something\",\"latex_columns\":\"something\",\"latex_data_caption\":\"Contenu de la table @TABLE@\",\"latex_data_continued_caption\":\"Contenu de la table @TABLE@ (suite)\",\"latex_data_label\":\"tab:@TABLE@-data\",\"latex_null\":\"\\\\textit{NULL}\",\"mediawiki_structure_or_data\":\"data\",\"mediawiki_caption\":\"something\",\"mediawiki_headers\":\"something\",\"htmlword_structure_or_data\":\"structure_and_data\",\"htmlword_null\":\"NULL\",\"ods_null\":\"NULL\",\"ods_structure_or_data\":\"data\",\"odt_structure_or_data\":\"structure_and_data\",\"odt_relation\":\"something\",\"odt_comments\":\"something\",\"odt_mime\":\"something\",\"odt_columns\":\"something\",\"odt_null\":\"NULL\",\"pdf_report_title\":\"\",\"pdf_structure_or_data\":\"data\",\"phparray_structure_or_data\":\"data\",\"sql_include_comments\":\"something\",\"sql_header_comment\":\"\",\"sql_use_transaction\":\"something\",\"sql_compatibility\":\"NONE\",\"sql_structure_or_data\":\"structure_and_data\",\"sql_create_table\":\"something\",\"sql_auto_increment\":\"something\",\"sql_create_view\":\"something\",\"sql_create_trigger\":\"something\",\"sql_backquotes\":\"something\",\"sql_type\":\"INSERT\",\"sql_insert_syntax\":\"both\",\"sql_max_query_size\":\"50000\",\"sql_hex_for_binary\":\"something\",\"sql_utc_time\":\"something\",\"texytext_structure_or_data\":\"structure_and_data\",\"texytext_null\":\"NULL\",\"yaml_structure_or_data\":\"data\",\"\":null,\"as_separate_files\":null,\"csv_removeCRLF\":null,\"excel_removeCRLF\":null,\"json_pretty_print\":null,\"htmlword_columns\":null,\"ods_columns\":null,\"sql_dates\":null,\"sql_relation\":null,\"sql_mime\":null,\"sql_disable_fk\":null,\"sql_views_as_tables\":null,\"sql_metadata\":null,\"sql_drop_database\":null,\"sql_drop_table\":null,\"sql_if_not_exists\":null,\"sql_simple_view_export\":null,\"sql_view_current_user\":null,\"sql_or_replace_view\":null,\"sql_procedure_function\":null,\"sql_truncate\":null,\"sql_delayed\":null,\"sql_ignore\":null,\"texytext_columns\":null}' WHERE `pma__export_templates`.`id` = 1;

-- --------------------------------------------------------

--
-- Structure de la table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Structure de la table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db` varchar(64) NOT NULL DEFAULT '',
  `table` varchar(64) NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Structure de la table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) NOT NULL,
  `item_name` varchar(64) NOT NULL,
  `item_type` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Structure de la table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Structure de la table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Déchargement des données de la table `pma__recent`
--

UPDATE `pma__recent` SET `username` = 'root',`tables` = '[{\"db\":\"promo_app\",\"table\":\"users\"},{\"db\":\"promo_app\",\"table\":\"deposit_methods\"},{\"db\":\"promo_app\",\"table\":\"bank_accounts\"},{\"db\":\"promo_app\",\"table\":\"tasks\"},{\"db\":\"promo_app\",\"table\":\"withdrawals\"},{\"db\":\"promo_app\",\"table\":\"deposits\"}]' WHERE `pma__recent`.`username` = 'root';

-- --------------------------------------------------------

--
-- Structure de la table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) NOT NULL DEFAULT '',
  `master_table` varchar(64) NOT NULL DEFAULT '',
  `master_field` varchar(64) NOT NULL DEFAULT '',
  `foreign_db` varchar(64) NOT NULL DEFAULT '',
  `foreign_table` varchar(64) NOT NULL DEFAULT '',
  `foreign_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Structure de la table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `search_name` varchar(64) NOT NULL DEFAULT '',
  `search_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Structure de la table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Structure de la table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `display_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Structure de la table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `prefs` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Structure de la table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text NOT NULL,
  `schema_sql` text DEFAULT NULL,
  `data_sql` longtext DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Structure de la table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Déchargement des données de la table `pma__userconfig`
--

UPDATE `pma__userconfig` SET `username` = 'root',`timevalue` = '2025-12-09 09:54:06',`config_data` = '{\"Console\\/Mode\":\"show\",\"lang\":\"fr\"}' WHERE `pma__userconfig`.`username` = 'root';

-- --------------------------------------------------------

--
-- Structure de la table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) NOT NULL,
  `tab` varchar(64) NOT NULL,
  `allowed` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Structure de la table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) NOT NULL,
  `usergroup` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Index pour la table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Index pour la table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Index pour la table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Index pour la table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Index pour la table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Index pour la table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Index pour la table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Index pour la table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Index pour la table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Index pour la table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Index pour la table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Index pour la table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Index pour la table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Index pour la table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Index pour la table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Index pour la table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Index pour la table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Base de données : `promo_app`
--
CREATE DATABASE IF NOT EXISTS `promo_app` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `promo_app`;

-- --------------------------------------------------------

--
-- Structure de la table `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `iban` varchar(255) DEFAULT NULL,
  `holder_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `bank_accounts`
--

UPDATE `bank_accounts` SET `id` = 1,`user_id` = 100000,`bank_name` = 'CIH',`iban` = '23571468745495',`holder_name` = 'abdellah',`created_at` = '2025-12-09 09:43:13' WHERE `bank_accounts`.`id` = 1;
UPDATE `bank_accounts` SET `id` = 2,`user_id` = 100003,`bank_name` = 'AWB',`iban` = '66474674647',`holder_name` = '!kul',`created_at` = '2025-12-09 10:22:19' WHERE `bank_accounts`.`id` = 2;

-- --------------------------------------------------------

--
-- Structure de la table `deposits`
--

CREATE TABLE `deposits` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `amount_cents` int(10) UNSIGNED NOT NULL,
  `status` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `full_name` varchar(255) DEFAULT NULL,
  `payer_rib` varchar(255) DEFAULT NULL,
  `screenshot_path` varchar(512) DEFAULT NULL,
  `method_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `deposits`
--

UPDATE `deposits` SET `id` = 1,`user_id` = 100001,`amount_cents` = 10000,`status` = 'CONFIRMED',`created_at` = '2025-12-09 09:37:19',`full_name` = 'tgps maroc',`payer_rib` = '15198498651654',`screenshot_path` = '/uploads/deposit_100001_1765273039524.jpg',`method_id` = 1 WHERE `deposits`.`id` = 1;
UPDATE `deposits` SET `id` = 2,`user_id` = 100002,`amount_cents` = 30000,`status` = 'CONFIRMED',`created_at` = '2025-12-09 10:07:13',`full_name` = 'abdellah nabih',`payer_rib` = '14118',`screenshot_path` = '/uploads/deposit_100002_1765274833214.jpg',`method_id` = 1 WHERE `deposits`.`id` = 2;
UPDATE `deposits` SET `id` = 3,`user_id` = 100003,`amount_cents` = 8000,`status` = 'CONFIRMED',`created_at` = '2025-12-09 10:21:48',`full_name` = 'OMAR',`payer_rib` = '586767474647',`screenshot_path` = '/uploads/deposit_100003_1765275708860.jpg',`method_id` = 1 WHERE `deposits`.`id` = 3;
UPDATE `deposits` SET `id` = 4,`user_id` = 100001,`amount_cents` = 10000,`status` = 'CONFIRMED',`created_at` = '2025-12-09 16:00:03',`full_name` = 'tgps maroc',`payer_rib` = '5181481518',`screenshot_path` = NULL,`method_id` = 1 WHERE `deposits`.`id` = 4;
UPDATE `deposits` SET `id` = 5,`user_id` = 100001,`amount_cents` = 100000,`status` = 'CONFIRMED',`created_at` = '2025-12-09 16:23:02',`full_name` = 'tgps maroc',`payer_rib` = '159548876545849819841691',`screenshot_path` = NULL,`method_id` = 1 WHERE `deposits`.`id` = 5;

-- --------------------------------------------------------

--
-- Structure de la table `deposit_methods`
--

CREATE TABLE `deposit_methods` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `recipient_name` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `rib` varchar(255) DEFAULT NULL,
  `motif` varchar(255) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `deposit_methods`
--

UPDATE `deposit_methods` SET `id` = 1,`bank_name` = 'CIH',`recipient_name` = 'Destinataire Demo',`account_number` = '0000-0000-0000-0000',`rib` = 'MA1234567890000000000000000',`motif` = 'Versement promo',`instructions` = 'Effectue le virement puis t?l?verse la capture.',`is_active` = 1,`created_at` = '2025-12-09 09:33:24' WHERE `deposit_methods`.`id` = 1;

-- --------------------------------------------------------

--
-- Structure de la table `referrals`
--

CREATE TABLE `referrals` (
  `id` int(10) UNSIGNED NOT NULL,
  `inviter_user_id` int(10) UNSIGNED NOT NULL,
  `invited_user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `referrals`
--

UPDATE `referrals` SET `id` = 1,`inviter_user_id` = 100001,`invited_user_id` = 100002,`created_at` = '2025-12-09 10:06:11' WHERE `referrals`.`id` = 1;

-- --------------------------------------------------------

--
-- Structure de la table `referral_bonuses`
--

CREATE TABLE `referral_bonuses` (
  `id` int(10) UNSIGNED NOT NULL,
  `deposit_id` int(10) UNSIGNED NOT NULL,
  `inviter_user_id` int(10) UNSIGNED NOT NULL,
  `invited_user_id` int(10) UNSIGNED NOT NULL,
  `bonus_cents` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `referral_bonuses`
--

UPDATE `referral_bonuses` SET `id` = 1,`deposit_id` = 2,`inviter_user_id` = 100001,`invited_user_id` = 100002,`bonus_cents` = 3000,`created_at` = '2025-12-09 10:09:57' WHERE `referral_bonuses`.`id` = 1;

-- --------------------------------------------------------

--
-- Structure de la table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `video_url` varchar(500) NOT NULL,
  `reward_cents` int(10) UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `duration_seconds` int(11) NOT NULL DEFAULT 15,
  `min_vip_level` varchar(20) DEFAULT 'FREE',
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `tasks`
--

UPDATE `tasks` SET `id` = 9,`title` = 'Vid?o Free 1',`video_url` = 'https://www.youtube.com/watch?v=Ei606gbdUz8&pp=ygUMYmVzdCBhbm5hbmNl',`reward_cents` = 200,`is_active` = 1,`created_at` = '2025-12-09 09:53:43',`duration_seconds` = 5,`min_vip_level` = 'FREE',`description` = 'Regarde au moins 5s.' WHERE `tasks`.`id` = 9;
UPDATE `tasks` SET `id` = 10,`title` = 'Vid?o Free 2',`video_url` = 'https://www.youtube.com/watch?v=O7W38_K8r9E&pp=ygUMYmVzdCBhbm5hbmNl',`reward_cents` = 250,`is_active` = 1,`created_at` = '2025-12-09 09:53:43',`duration_seconds` = 5,`min_vip_level` = 'FREE',`description` = 'Regarde au moins 5s.' WHERE `tasks`.`id` = 10;
UPDATE `tasks` SET `id` = 11,`title` = 'Vidéo VIP 1',`video_url` = 'https://www.youtube.com/watch?v=kg-g7ERIXb8&pp=ygUMYmVzdCBhbm5hbmNl',`reward_cents` = 500,`is_active` = 1,`created_at` = '2025-12-09 09:53:43',`duration_seconds` = 15,`min_vip_level` = 'VIP',`description` = 'Regarde au moins 15s.' WHERE `tasks`.`id` = 11;
UPDATE `tasks` SET `id` = 12,`title` = 'Vidéo VIP 2',`video_url` = 'https://www.youtube.com/watch?v=Vh8CorXMX-c&pp=ygUMYmVzdCBhbm5hbmNl',`reward_cents` = 550,`is_active` = 1,`created_at` = '2025-12-09 09:53:43',`duration_seconds` = 15,`min_vip_level` = 'VIP',`description` = 'Regarde au moins 15s.' WHERE `tasks`.`id` = 12;
UPDATE `tasks` SET `id` = 13,`title` = 'Vidéo VIP 3',`video_url` = 'https://www.youtube.com/watch?v=BwBbc_mGfn4&pp=ygUMYmVzdCBhbm5hbmNl',`reward_cents` = 300,`is_active` = 1,`created_at` = '2025-12-09 09:53:43',`duration_seconds` = 15,`min_vip_level` = 'VIP',`description` = 'Regarde au moins 15s.' WHERE `tasks`.`id` = 13;
UPDATE `tasks` SET `id` = 14,`title` = 'Vidéo VIP 4',`video_url` = 'https://www.youtube.com/watch?v=FL36BSMhRMA&pp=ygUMYmVzdCBhbm5hbmNl',`reward_cents` = 650,`is_active` = 1,`created_at` = '2025-12-09 09:53:43',`duration_seconds` = 15,`min_vip_level` = 'VIP',`description` = 'Regarde au moins 15s.' WHERE `tasks`.`id` = 14;

-- --------------------------------------------------------

--
-- Structure de la table `task_completions`
--

CREATE TABLE `task_completions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED NOT NULL,
  `reward_cents` int(10) UNSIGNED NOT NULL,
  `balance_before_cents` int(10) UNSIGNED NOT NULL,
  `balance_after_cents` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `task_completions`
--

UPDATE `task_completions` SET `id` = 3,`user_id` = 100001,`task_id` = 9,`reward_cents` = 200,`balance_before_cents` = 400,`balance_after_cents` = 600,`created_at` = '2025-12-09 09:56:03' WHERE `task_completions`.`id` = 3;
UPDATE `task_completions` SET `id` = 4,`user_id` = 100001,`task_id` = 10,`reward_cents` = 250,`balance_before_cents` = 600,`balance_after_cents` = 850,`created_at` = '2025-12-09 09:56:12' WHERE `task_completions`.`id` = 4;
UPDATE `task_completions` SET `id` = 5,`user_id` = 100002,`task_id` = 9,`reward_cents` = 200,`balance_before_cents` = 0,`balance_after_cents` = 200,`created_at` = '2025-12-09 10:07:31' WHERE `task_completions`.`id` = 5;
UPDATE `task_completions` SET `id` = 6,`user_id` = 100002,`task_id` = 10,`reward_cents` = 250,`balance_before_cents` = 200,`balance_after_cents` = 450,`created_at` = '2025-12-09 10:07:49' WHERE `task_completions`.`id` = 6;
UPDATE `task_completions` SET `id` = 7,`user_id` = 100002,`task_id` = 11,`reward_cents` = 500,`balance_before_cents` = 22450,`balance_after_cents` = 22950,`created_at` = '2025-12-09 10:12:21' WHERE `task_completions`.`id` = 7;
UPDATE `task_completions` SET `id` = 8,`user_id` = 100002,`task_id` = 12,`reward_cents` = 550,`balance_before_cents` = 22950,`balance_after_cents` = 23500,`created_at` = '2025-12-09 10:12:49' WHERE `task_completions`.`id` = 8;
UPDATE `task_completions` SET `id` = 9,`user_id` = 100002,`task_id` = 13,`reward_cents` = 300,`balance_before_cents` = 23500,`balance_after_cents` = 23800,`created_at` = '2025-12-09 10:15:31' WHERE `task_completions`.`id` = 9;
UPDATE `task_completions` SET `id` = 10,`user_id` = 100002,`task_id` = 14,`reward_cents` = 650,`balance_before_cents` = 23800,`balance_after_cents` = 24450,`created_at` = '2025-12-09 10:15:52' WHERE `task_completions`.`id` = 10;
UPDATE `task_completions` SET `id` = 11,`user_id` = 100003,`task_id` = 9,`reward_cents` = 200,`balance_before_cents` = 0,`balance_after_cents` = 200,`created_at` = '2025-12-09 10:20:07' WHERE `task_completions`.`id` = 11;
UPDATE `task_completions` SET `id` = 12,`user_id` = 100003,`task_id` = 10,`reward_cents` = 250,`balance_before_cents` = 200,`balance_after_cents` = 450,`created_at` = '2025-12-09 10:20:27' WHERE `task_completions`.`id` = 12;
UPDATE `task_completions` SET `id` = 13,`user_id` = 100003,`task_id` = 11,`reward_cents` = 500,`balance_before_cents` = 72000,`balance_after_cents` = 72500,`created_at` = '2025-12-09 16:04:57' WHERE `task_completions`.`id` = 13;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `vip_level` enum('FREE','VIP') NOT NULL DEFAULT 'FREE',
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `balance_cents` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `invite_code` varchar(32) DEFAULT NULL,
  `invited_by_user_id` int(11) DEFAULT NULL,
  `vip_expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

UPDATE `users` SET `id` = 100000,`full_name` = 'abdellah',`email` = 'contact-tgps@proton.me',`password_hash` = '$2b$10$lFqJh0MALJcd3tAljuFF8edX0ubUy/lpVtDbx8iMtA2pUZTlld4Ei',`vip_level` = 'FREE',`role` = 'admin',`balance_cents` = 0,`created_at` = '2025-12-09 09:30:00',`invite_code` = '58AK549R',`invited_by_user_id` = NULL,`vip_expires_at` = NULL WHERE `users`.`id` = 100000;
UPDATE `users` SET `id` = 100001,`full_name` = 'tgps maroc',`email` = 'contact-tgps@proton.ma',`password_hash` = '$2b$10$CeuvCof1kVjau9bz6gyQJOlpRtFtl.i4RwG5yvCbg1reBakbKBxZS',`vip_level` = 'VIP',`role` = 'user',`balance_cents` = 73850,`created_at` = '2025-12-09 09:33:03',`invite_code` = 'N23LUENN',`invited_by_user_id` = NULL,`vip_expires_at` = '2026-03-09 17:35:11' WHERE `users`.`id` = 100001;
UPDATE `users` SET `id` = 100002,`full_name` = 'abdellah nabih',`email` = 'contact-tgps@proton.cc',`password_hash` = '$2b$10$wJIFMc4dZOX8qXBHp7Tw8uOBqQQCMQJUwuUsFbIhXS73H0dv8WEo2',`vip_level` = 'FREE',`role` = 'user',`balance_cents` = 24450,`created_at` = '2025-12-09 10:06:11',`invite_code` = 'APFVQQ8G',`invited_by_user_id` = 100001,`vip_expires_at` = NULL WHERE `users`.`id` = 100002;
UPDATE `users` SET `id` = 100003,`full_name` = 'OMAR',`email` = 'omar.elou14@gmail.com',`password_hash` = '$2b$10$pfktj5uPrxjJB.12LgBNs.youPoTUlmSMWGkLnChwIdFy6hynOXEa',`vip_level` = 'FREE',`role` = 'user',`balance_cents` = 62500,`created_at` = '2025-12-09 10:19:22',`invite_code` = '8JTD7D5M',`invited_by_user_id` = NULL,`vip_expires_at` = NULL WHERE `users`.`id` = 100003;

-- --------------------------------------------------------

--
-- Structure de la table `withdrawals`
--

CREATE TABLE `withdrawals` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `amount_cents` int(10) UNSIGNED NOT NULL,
  `status` enum('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
  `type` enum('WITHDRAW','VIP_UPGRADE') NOT NULL DEFAULT 'WITHDRAW',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `withdrawals`
--

UPDATE `withdrawals` SET `id` = 1,`user_id` = 100001,`amount_cents` = 8000,`status` = 'APPROVED',`type` = 'VIP_UPGRADE',`created_at` = '2025-12-09 09:38:37' WHERE `withdrawals`.`id` = 1;
UPDATE `withdrawals` SET `id` = 2,`user_id` = 100001,`amount_cents` = 2000,`status` = 'APPROVED',`type` = 'WITHDRAW',`created_at` = '2025-12-09 09:45:06' WHERE `withdrawals`.`id` = 2;
UPDATE `withdrawals` SET `id` = 3,`user_id` = 100002,`amount_cents` = 8000,`status` = 'APPROVED',`type` = 'VIP_UPGRADE',`created_at` = '2025-12-09 10:10:25' WHERE `withdrawals`.`id` = 3;
UPDATE `withdrawals` SET `id` = 4,`user_id` = 100003,`amount_cents` = 8000,`status` = 'APPROVED',`type` = 'VIP_UPGRADE',`created_at` = '2025-12-09 10:24:48' WHERE `withdrawals`.`id` = 4;
UPDATE `withdrawals` SET `id` = 5,`user_id` = 100003,`amount_cents` = 8000,`status` = 'APPROVED',`type` = 'VIP_UPGRADE',`created_at` = '2025-12-09 16:04:24' WHERE `withdrawals`.`id` = 5;
UPDATE `withdrawals` SET `id` = 6,`user_id` = 100003,`amount_cents` = 10000,`status` = 'APPROVED',`type` = 'WITHDRAW',`created_at` = '2025-12-09 16:05:10' WHERE `withdrawals`.`id` = 6;
UPDATE `withdrawals` SET `id` = 7,`user_id` = 100001,`amount_cents` = 8000,`status` = 'APPROVED',`type` = 'VIP_UPGRADE',`created_at` = '2025-12-09 16:14:52' WHERE `withdrawals`.`id` = 7;
UPDATE `withdrawals` SET `id` = 8,`user_id` = 100001,`amount_cents` = 8000,`status` = 'APPROVED',`type` = 'VIP_UPGRADE',`created_at` = '2025-12-09 16:24:43' WHERE `withdrawals`.`id` = 8;
UPDATE `withdrawals` SET `id` = 9,`user_id` = 100001,`amount_cents` = 8000,`status` = 'APPROVED',`type` = 'VIP_UPGRADE',`created_at` = '2025-12-09 16:26:42' WHERE `withdrawals`.`id` = 9;
UPDATE `withdrawals` SET `id` = 10,`user_id` = 100001,`amount_cents` = 8000,`status` = 'APPROVED',`type` = 'VIP_UPGRADE',`created_at` = '2025-12-09 16:28:45' WHERE `withdrawals`.`id` = 10;
UPDATE `withdrawals` SET `id` = 11,`user_id` = 100001,`amount_cents` = 8000,`status` = 'APPROVED',`type` = 'VIP_UPGRADE',`created_at` = '2025-12-09 16:35:11' WHERE `withdrawals`.`id` = 11;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Index pour la table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_deposits_user` (`user_id`);

--
-- Index pour la table `deposit_methods`
--
ALTER TABLE `deposit_methods`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `referrals`
--
ALTER TABLE `referrals`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invited_user_id` (`invited_user_id`),
  ADD KEY `fk_referrals_inviter` (`inviter_user_id`);

--
-- Index pour la table `referral_bonuses`
--
ALTER TABLE `referral_bonuses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `deposit_id` (`deposit_id`),
  ADD KEY `fk_refbonus_inviter` (`inviter_user_id`),
  ADD KEY `fk_refbonus_invited` (`invited_user_id`);

--
-- Index pour la table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `task_completions`
--
ALTER TABLE `task_completions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ux_task_user` (`user_id`,`task_id`),
  ADD KEY `fk_task_completions_task` (`task_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `invite_code` (`invite_code`);

--
-- Index pour la table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_withdrawals_user` (`user_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `deposit_methods`
--
ALTER TABLE `deposit_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `referrals`
--
ALTER TABLE `referrals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `referral_bonuses`
--
ALTER TABLE `referral_bonuses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `task_completions`
--
ALTER TABLE `task_completions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100004;

--
-- AUTO_INCREMENT pour la table `withdrawals`
--
ALTER TABLE `withdrawals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD CONSTRAINT `bank_accounts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `deposits`
--
ALTER TABLE `deposits`
  ADD CONSTRAINT `fk_deposits_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `referrals`
--
ALTER TABLE `referrals`
  ADD CONSTRAINT `fk_referrals_invited` FOREIGN KEY (`invited_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_referrals_inviter` FOREIGN KEY (`inviter_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `referral_bonuses`
--
ALTER TABLE `referral_bonuses`
  ADD CONSTRAINT `fk_refbonus_deposit` FOREIGN KEY (`deposit_id`) REFERENCES `deposits` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_refbonus_invited` FOREIGN KEY (`invited_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_refbonus_inviter` FOREIGN KEY (`inviter_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `task_completions`
--
ALTER TABLE `task_completions`
  ADD CONSTRAINT `fk_task_completions_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_task_completions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD CONSTRAINT `fk_withdrawals_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
--
-- Base de données : `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
